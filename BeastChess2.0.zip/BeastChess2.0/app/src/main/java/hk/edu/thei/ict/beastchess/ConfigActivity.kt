package hk.edu.thei.ict.beastchess

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * ConfigActivity manages user application settings (such as toggling sound effects)
 * and provides navigation to HistoryActivity to inspect or erase SQLite game records.
 */
class ConfigActivity : AppCompatActivity() {

    private lateinit var switchSound: Switch
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        // Bind UI controls from activity_config.xml
        switchSound = findViewById(R.id.switchSound)
        val btnViewHistory = findViewById<Button>(R.id.btnViewHistory)
        val btnSaveConfig = findViewById<Button>(R.id.btnSaveConfig)

        // Retrieve current sound preference from SharedPreferences and update the Switch state
        sharedPreferences = getSharedPreferences("BeastChessPrefs", MODE_PRIVATE)
        switchSound.isChecked = sharedPreferences.getBoolean("soundEnabled", true)

        // Launch HistoryActivity to view past match outcomes stored in the SQLite database
        btnViewHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // Save updated configuration settings to SharedPreferences and return to the previous screen
        btnSaveConfig.setOnClickListener {
            sharedPreferences.edit().putBoolean("soundEnabled", switchSound.isChecked).apply()
            Toast.makeText(this, "Preferences Saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}