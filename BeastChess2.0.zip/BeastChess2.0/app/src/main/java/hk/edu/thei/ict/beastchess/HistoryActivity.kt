package hk.edu.thei.ict.beastchess

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * HistoryActivity displays all saved match records from the SQLite database
 * and allows the user to clear the match history table.
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var tvHistoryLogs: TextView
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        // Initialize UI components
        tvHistoryLogs = findViewById(R.id.tvHistoryLogs)
        val btnClearHistory = findViewById<Button>(R.id.btnClearHistory)
        val btnBackConfig = findViewById<Button>(R.id.btnBackConfig)

        // Initialize SQLite Database Helper and load records
        dbHelper = DatabaseHelper(this)
        loadRecords()

        // Erase all records from the game_records table when clicked
        btnClearHistory.setOnClickListener {
            dbHelper.clearAllGameRecords()
            loadRecords() // Refresh the TextView to show empty state
            Toast.makeText(this, "All match records erased!", Toast.LENGTH_SHORT).show()
        }

        // Return to ConfigActivity
        btnBackConfig.setOnClickListener {
            finish()
        }
    }

    /**
     * Queries the SQLite database for all game records and updates the TextView.
     */
    private fun loadRecords() {
        val recordsText = dbHelper.getAllGameRecords()
        if (recordsText.isNotBlank()) {
            tvHistoryLogs.text = recordsText
        } else {
            tvHistoryLogs.text = "No win-lose records found yet. Play a game first!"
        }
    }
}