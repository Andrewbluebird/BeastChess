package hk.edu.thei.ict.beastchess

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * DatabaseHelper manages the local SQLite database for user authentication
 * and storing/clearing game match history records.
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "BeastChess.db"
        private const val DATABASE_VERSION = 2

        // Table and columns for User Authentication
        const val TABLE_USERS = "users"
        const val COLUMN_USER_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"

        // Table and columns for Game Round Records
        const val TABLE_GAME_RECORDS = "game_records"
        const val COLUMN_RECORD_ID = "record_id"
        const val COLUMN_REC_USERNAME = "username"
        const val COLUMN_ROUND_NUMBER = "round_number"
        const val COLUMN_GAME_METRIC = "game_metric" // Stores Game Mode & Win-Lose Outcome
        const val COLUMN_SYSTEM_TIME = "system_time"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Create Users table for login authentication
        val createUsersTable = ("CREATE TABLE $TABLE_USERS (" +
                "$COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_USERNAME TEXT UNIQUE, " +
                "$COLUMN_PASSWORD TEXT)")
        db?.execSQL(createUsersTable)

        // Create Game Records table with required assignment attributes
        val createRecordsTable = ("CREATE TABLE $TABLE_GAME_RECORDS (" +
                "$COLUMN_RECORD_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_REC_USERNAME TEXT, " +
                "$COLUMN_ROUND_NUMBER INTEGER, " +
                "$COLUMN_GAME_METRIC TEXT, " +
                "$COLUMN_SYSTEM_TIME TEXT)")
        db?.execSQL(createRecordsTable)

        // Seed default user account (User715 / imthescatman)
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, "User715")
            put(COLUMN_PASSWORD, "imthescatman")
        }
        db?.insert(TABLE_USERS, null, values)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_GAME_RECORDS")
        onCreate(db)
    }

    /**
     * Checks if the provided username and password match a record in the users table.
     */
    fun checkUser(username: String, pass: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            arrayOf(COLUMN_USER_ID),
            "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?",
            arrayOf(username, pass),
            null, null, null
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    /**
     * Inserts a completed game round record into the game_records table.
     * Automatically calculates the next round number based on existing rows.
     */
    fun insertGameRecord(username: String, roundNumber: Int, gameMetric: String) {
        val db = this.writableDatabase
        val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        // Calculate dynamic round number based on existing rows
        val countCursor = db.rawQuery("SELECT COUNT(*) FROM $TABLE_GAME_RECORDS", null)
        var actualRound = roundNumber
        if (countCursor.moveToFirst()) {
            actualRound = countCursor.getInt(0) + 1
        }
        countCursor.close()

        val values = ContentValues().apply {
            put(COLUMN_REC_USERNAME, username)
            put(COLUMN_ROUND_NUMBER, actualRound)
            put(COLUMN_GAME_METRIC, gameMetric)
            put(COLUMN_SYSTEM_TIME, currentTime)
        }
        db.insert(TABLE_GAME_RECORDS, null, values)
    }

    /**
     * Retrieves all saved game records formatted as a string for HistoryActivity.
     */
    fun getAllGameRecords(): String {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_GAME_RECORDS ORDER BY $COLUMN_RECORD_ID DESC", null)
        val resultBuilder = StringBuilder()

        if (cursor.moveToFirst()) {
            do {
                val user = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_REC_USERNAME))
                val round = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ROUND_NUMBER))
                val metric = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GAME_METRIC))
                val time = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SYSTEM_TIME))

                resultBuilder.append("Round #$round | Player: $user\n")
                resultBuilder.append("Result: $metric\n")
                resultBuilder.append("Time: $time\n")
                resultBuilder.append("----------------------------------------\n")
            } while (cursor.moveToNext())
        }
        cursor.close()
        return resultBuilder.toString()
    }

    /**
     * Deletes all rows from the game_records table and resets the auto-increment counter.
     */
    fun clearAllGameRecords() {
        val db = this.writableDatabase
        // Delete all rows from the game records table
        db.delete(TABLE_GAME_RECORDS, null, null)
        // Reset the SQLite auto-increment sequence for this table
        db.execSQL("DELETE FROM sqlite_sequence WHERE name = '$TABLE_GAME_RECORDS'")
    }
}