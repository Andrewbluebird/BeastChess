package hk.edu.thei.ict.beastchess

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity acts as the central navigation hub (Main Menu) of the Beast Chess app.
 * From here, authenticated users can start a game via ModeSelectActivity,
 * adjust settings/view match history via ConfigActivity, or log out of their session.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Bind navigation buttons from activity_main.xml
        val btnPlay = findViewById<Button>(R.id.btnPlay)
        val btnConfig = findViewById<Button>(R.id.btnConfig)
        val btnLogout = findViewById<Button>(R.id.btnLogout)

        // Navigate to ModeSelectActivity so the player can choose Single Player or Multiplayer
        btnPlay.setOnClickListener {
            startActivity(Intent(this, ModeSelectActivity::class.java))
        }

        // Navigate to ConfigActivity to manage preferences and view SQLite match history
        btnConfig.setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }

        // Log out the current user by clearing saved SharedPreferences and returning to LoginActivity
        btnLogout.setOnClickListener {
            val prefs = getSharedPreferences("BeastChessPrefs", MODE_PRIVATE)
            prefs.edit().clear().apply()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}