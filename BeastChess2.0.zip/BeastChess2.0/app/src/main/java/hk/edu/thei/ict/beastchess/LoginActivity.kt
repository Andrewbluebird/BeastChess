package hk.edu.thei.ict.beastchess

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * LoginActivity serves as the initial entry point (Launcher) of the application.
 * It handles user authentication by validating credentials against the SQLite database
 * and persists the active login session using SharedPreferences.
 */
class LoginActivity : AppCompatActivity() {

    // UI elements for user credential input and form submission
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button

    // Storage helpers for session persistence and SQLite database queries
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var dbHelper: DatabaseHelper

    companion object {
        // Constants for SharedPreferences file name and session keys
        private const val PREF_NAME = "BeastChessPrefs"
        private const val KEY_IS_LOGGED_IN = "isLoggedIn"
        const val KEY_USERNAME = "username"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize SharedPreferences and the SQLite DatabaseHelper
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE)
        dbHelper = DatabaseHelper(this)

        // Check if an active login session already exists; if so, bypass the login screen
        if (sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        // Bind the activity to its XML layout
        setContentView(R.layout.activity_login)

        // Link UI variables to their corresponding views in activity_login.xml
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)

        // Handle login button click events
        btnLogin.setOnClickListener {
            // Retrieve and trim user input from the text fields
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            // Query the SQLite database to verify if the username and password are valid
            if (dbHelper.checkUser(username, password)) {
                // Save the logged-in state and active username into SharedPreferences
                sharedPreferences.edit().apply {
                    putBoolean(KEY_IS_LOGGED_IN, true)
                    putString(KEY_USERNAME, username)
                    apply()
                }

                // Notify the user of successful authentication and navigate to MainActivity
                Toast.makeText(this, "Login Successful via SQLite!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                // Display an error message if credentials do not match any database record
                Toast.makeText(this, "Invalid Database Credentials", Toast.LENGTH_SHORT).show()
            }
        }
    }
}