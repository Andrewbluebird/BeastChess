package hk.edu.thei.ict.beastchess

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

/**
 * ModeSelectActivity allows players to select between Single Player (vs AI Bot)
 * and Local Multiplayer (2 players on the same device), as well as configure
 * the AI Bot difficulty level before launching GameActivity.
 */
class ModeSelectActivity : AppCompatActivity() {

    private lateinit var spinnerDifficulty: Spinner
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mode_select)

        // Initialize UI components from activity_mode_select.xml
        spinnerDifficulty = findViewById(R.id.spinnerDifficulty)
        val btnSinglePlayer = findViewById<Button>(R.id.btnSinglePlayer)
        val btnMultiplayer = findViewById<Button>(R.id.btnMultiplayer)
        val btnModeQuit = findViewById<Button>(R.id.btnModeQuit)

        // Load SharedPreferences to read and store mode/difficulty selections
        sharedPreferences = getSharedPreferences("BeastChessPrefs", MODE_PRIVATE)

        // Populate the difficulty Spinner using the string-array defined in res/values/strings.xml
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.difficulty_options,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDifficulty.adapter = adapter

        // Restore the previously selected difficulty level (defaults to 0 / Easy)
        spinnerDifficulty.setSelection(sharedPreferences.getInt("difficultyIndex", 0))

        // Start a Single Player match against the AI Bot
        btnSinglePlayer.setOnClickListener {
            saveSettings(isSingle = true)
            startActivity(Intent(this, GameActivity::class.java))
        }

        // Start a Local Multiplayer match (Player 1 Red vs Player 2 Blue)
        btnMultiplayer.setOnClickListener {
            saveSettings(isSingle = false)
            startActivity(Intent(this, GameActivity::class.java))
        }

        // Close ModeSelectActivity and return to the Main Menu
        btnModeQuit.setOnClickListener {
            finish()
        }
    }

    /**
     * Saves the chosen game mode (Single Player vs Multiplayer) and AI difficulty index
     * into SharedPreferences so GameActivity can configure the match accordingly.
     */
    private fun saveSettings(isSingle: Boolean) {
        sharedPreferences.edit().apply {
            putBoolean("isSinglePlayer", isSingle)
            putInt("difficultyIndex", spinnerDifficulty.selectedItemPosition)
            apply()
        }
    }
}