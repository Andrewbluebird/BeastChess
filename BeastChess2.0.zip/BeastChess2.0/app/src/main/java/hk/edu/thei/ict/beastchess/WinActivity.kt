package hk.edu.thei.ict.beastchess

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * WinActivity is displayed when a match concludes in GameActivity.
 * It announces the winner of the round and allows the player to immediately
 * start a rematch or return to the Main Menu.
 */
class WinActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_win)

        // Bind UI elements from activity_win.xml
        val tvWinnerResult = findViewById<TextView>(R.id.tvWinnerResult)
        val btnPlayAgain = findViewById<Button>(R.id.btnPlayAgain)
        val btnMainMenu = findViewById<Button>(R.id.btnMainMenu)

        // Retrieve the winning outcome string passed via Intent from GameActivity
        val winnerMessage = intent.getStringExtra("WINNER_TEXT") ?: "Game Over"
        tvWinnerResult.text = winnerMessage

        // Start a new match in GameActivity using the current mode settings
        btnPlayAgain.setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
            finish()
        }

        // Return to MainActivity and clear the activity back stack
        btnMainMenu.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }
}