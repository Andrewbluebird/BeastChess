package hk.edu.thei.ict.beastchess

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.random.Random

/**
 * GameActivity manages the core 7x9 Beast Chess (Jungle Chess) board,
 * piece movement rules, special river-jumping mechanics, AI bot moves,
 * and records match results into the SQLite database upon completion.
 */
class GameActivity : AppCompatActivity() {

    private lateinit var boardLayout: GridLayout
    private lateinit var tvTurn: TextView
    private lateinit var btnQuit: Button
    private val boardButtons = Array(9) { arrayOfNulls<Button>(7) }

    // 7x9 Jungle Chess initial board state
    // Positive values (1 to 8) = Player 1 (Red Team)
    // Negative values (-1 to -8) = Player 2 / Bot (Blue Team)
    // Ranks: 1=Rat/Mouse, 2=Cat, 3=Dog, 4=Wolf, 5=Leopard, 6=Tiger, 7=Lion, 8=Elephant
    private val boardState = arrayOf(
        intArrayOf(-7,  0,  0,  0,  0,  0,  -8),
        intArrayOf( 0, -3,  0,  0,  0, -2,   0),
        intArrayOf(-1,  0, -5,  0, -4,  0,  -6),
        intArrayOf( 0,  0,  0,  0,  0,  0,   0),
        intArrayOf( 0,  0,  0,  0,  0,  0,   0),
        intArrayOf( 0,  0,  0,  0,  0,  0,   0),
        intArrayOf( 6,  0,  5,  0,  4,  0,   1),
        intArrayOf( 0,  2,  0,  0,  0,  3,   0),
        intArrayOf( 8,  0,  0,  0,  0,  0,   7)
    )

    private var isPlayer1Turn = true
    private var selectedRow = -1
    private var selectedCol = -1

    private var isSinglePlayer = true
    private var difficultyIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        // Initialize UI components
        boardLayout = findViewById(R.id.boardLayout)
        tvTurn = findViewById(R.id.tvTurn)
        btnQuit = findViewById(R.id.btnQuit)

        // Retrieve game mode and difficulty settings from SharedPreferences
        val prefs = getSharedPreferences("BeastChessPrefs", MODE_PRIVATE)
        isSinglePlayer = prefs.getBoolean("isSinglePlayer", true)
        difficultyIndex = prefs.getInt("difficultyIndex", 0)

        // Quit button returns the user to the Main Menu
        btnQuit.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        initializeBoardUI()
    }

    /**
     * Dynamically populates the 7x9 GridLayout with interactive buttons for each tile.
     */
    private fun initializeBoardUI() {
        for (r in 0..8) {
            for (c in 0..6) {
                val btn = Button(this).apply {
                    layoutParams = GridLayout.LayoutParams().apply {
                        width = 110
                        height = 110
                        setMargins(1, 1, 1, 1)
                    }
                }

                // Handle tile clicks when it is a human player's turn
                btn.setOnClickListener {
                    if (isPlayer1Turn || !isSinglePlayer) {
                        onTileClicked(r, c)
                    }
                }
                boardButtons[r][c] = btn
                boardLayout.addView(btn)
            }
        }
        updateBoardDisplay()
    }

    /**
     * Updates the visual appearance of every tile on the board, rendering custom
     * animal piece drawables or terrain backgrounds (River, Trap, Den, Land).
     */
    private fun updateBoardDisplay() {
        for (r in 0..8) {
            for (c in 0..6) {
                val piece = boardState[r][c]
                val btn = boardButtons[r][c] ?: continue

                // Clear button text so custom image drawables display cleanly
                btn.text = ""

                if (piece != 0) {
                    // Display the corresponding Red or Blue animal image
                    val imgRes = getPieceDrawable(piece)
                    btn.setBackgroundResource(imgRes)
                } else {
                    // Display terrain colors/textures for empty squares
                    when {
                        isRiver(r, c) -> btn.setBackgroundColor(Color.CYAN)
                        isTrap(r, c) -> btn.setBackgroundResource(R.drawable.bg_trap)
                        isDen(r, c) -> btn.setBackgroundResource(R.drawable.bg_den)
                        else -> btn.setBackgroundColor(Color.LTGRAY)
                    }
                }
            }
        }
    }

    /**
     * Maps piece integer values to their corresponding custom PNG drawables in res/drawable.
     */
    private fun getPieceDrawable(piece: Int): Int {
        val isRed = piece > 0
        return when (abs(piece)) {
            1 -> if (isRed) R.drawable.redmouse else R.drawable.bluemouse
            2 -> if (isRed) R.drawable.redcat else R.drawable.bluecat
            3 -> if (isRed) R.drawable.reddog else R.drawable.bluedog
            4 -> if (isRed) R.drawable.redwolf else R.drawable.bluewolf
            5 -> if (isRed) R.drawable.redleopard else R.drawable.blueleopard
            6 -> if (isRed) R.drawable.redtiger else R.drawable.bluetiger
            7 -> if (isRed) R.drawable.redlion else R.drawable.bluelion
            8 -> if (isRed) R.drawable.redelephant else R.drawable.blueelephant
            else -> android.R.color.transparent
        }
    }

    // Helper methods to identify special board coordinates
    private fun isRiver(r: Int, c: Int): Boolean {
        return (r in 3..5) && (c == 1 || c == 2 || c == 4 || c == 5)
    }

    private fun isTrap(r: Int, c: Int): Boolean {
        return (r == 0 && (c == 2 || c == 4)) || (r == 1 && c == 3) ||
                (r == 8 && (c == 2 || c == 4)) || (r == 7 && c == 3)
    }

    private fun isDen(r: Int, c: Int): Boolean {
        return (r == 0 && c == 3) || (r == 8 && c == 3)
    }

    /**
     * Handles two-step tile selection: first click selects the player's piece,
     * second click attempts to move it to the target coordinate.
     */
    private fun onTileClicked(r: Int, c: Int) {
        val piece = boardState[r][c]

        if (selectedRow == -1 && selectedCol == -1) {
            // Select piece if it belongs to the current active player
            if ((isPlayer1Turn && piece > 0) || (!isPlayer1Turn && piece < 0)) {
                selectedRow = r
                selectedCol = c
                Toast.makeText(this, "Piece Selected", Toast.LENGTH_SHORT).show()
            }
        } else {
            // Validate and execute move to the target tile
            if (isValidMove(selectedRow, selectedCol, r, c)) {
                executeMove(selectedRow, selectedCol, r, c)
            } else {
                Toast.makeText(this, "Invalid Move!", Toast.LENGTH_SHORT).show()
                selectedRow = -1
                selectedCol = -1
            }
        }
    }

    /**
     * Moves a piece on the board, checks if a Den was captured to end the round,
     * logs the match record to SQLite, and switches turns.
     */
    private fun executeMove(startR: Int, startC: Int, endR: Int, endC: Int) {
        val movingPiece = boardState[startR][startC]
        boardState[endR][endC] = movingPiece
        boardState[startR][startC] = 0

        // Check Win Condition: Player 1 reaches top Den (0,3) or Player 2/Bot reaches bottom Den (8,3)
        if ((movingPiece > 0 && endR == 0 && endC == 3) ||
            (movingPiece < 0 && endR == 8 && endC == 3)) {

            val winText = if (movingPiece > 0) {
                "Player 1 (Red) Wins!"
            } else if (isSinglePlayer) {
                "Bot Wins!"
            } else {
                "Player 2 (Blue) Wins!"
            }

            // Retrieve current logged-in username and format the game mode + result
            val prefs = getSharedPreferences("BeastChessPrefs", MODE_PRIVATE)
            val currentUsername = prefs.getString("username", "User715") ?: "User715"
            val modeName = if (isSinglePlayer) "Single Player" else "Local Multiplayer"

            // Save match record to SQLite database (Username, auto-incremented Round #, Mode/Result, System Time)
            val dbHelper = DatabaseHelper(this)
            dbHelper.insertGameRecord(
                username = currentUsername,
                roundNumber = 0, // DatabaseHelper automatically calculates the next round number
                gameMetric = "[$modeName] $winText"
            )

            // Transition to WinActivity
            val intent = Intent(this, WinActivity::class.java).apply {
                putExtra("WINNER_TEXT", winText)
            }
            startActivity(intent)
            finish()
            return
        }

        // Switch active turn
        isPlayer1Turn = !isPlayer1Turn
        tvTurn.text = if (isPlayer1Turn) {
            "Turn: Player 1 (Red)"
        } else if (isSinglePlayer) {
            "Turn: Bot Thinking..."
        } else {
            "Turn: Player 2 (Blue)"
        }

        selectedRow = -1
        selectedCol = -1
        updateBoardDisplay()

        // Trigger AI Bot move after a short delay if in Single Player mode
        if (isSinglePlayer && !isPlayer1Turn) {
            Handler(Looper.getMainLooper()).postDelayed({ makeBotMove() }, 700)
        }
    }

    /**
     * Validates movement rules including orthogonal steps, Lion/Tiger river jumps,
     * water entry restrictions, and piece rank combat hierarchy.
     */
    private fun isValidMove(startR: Int, startC: Int, endR: Int, endC: Int): Boolean {
        val attacker = boardState[startR][startC]
        val defender = boardState[endR][endC]

        if (attacker == 0) return false
        // Prevent capturing friendly pieces
        if (defender != 0 && ((attacker > 0 && defender > 0) || (attacker < 0 && defender < 0))) {
            return false
        }

        // Prevent a player from stepping into their own Den
        if ((attacker > 0 && endR == 8 && endC == 3) || (attacker < 0 && endR == 0 && endC == 3)) {
            return false
        }

        val rowDiff = abs(startR - endR)
        val colDiff = abs(startC - endC)
        val absAttacker = abs(attacker)

        val isNormalStep = (rowDiff + colDiff == 1)
        var isRiverJump = false

        // Special Rule: Lion (7) and Tiger (6) can jump across the river
        // Horizontal river jump spans 3 columns (e.g., col 0 to 3); Vertical spans 4 rows (row 2 to 6) or 2 water rows
        if ((absAttacker == 6 || absAttacker == 7) &&
            ((rowDiff == 0 && (colDiff == 3 || colDiff == 4)) || (colDiff == 0 && (rowDiff == 2 || rowDiff == 3 || rowDiff == 4)))) {
            isRiverJump = checkRiverJumpPath(startR, startC, endR, endC)
        }

        if (!isNormalStep && !isRiverJump) return false

        // Only the Rat/Mouse (Rank 1) can enter river tiles
        if (isRiver(endR, endC) && absAttacker != 1) return false

        // Combat hierarchy check when landing on an opponent's piece
        if (defender != 0) {
            val absDefender = abs(defender)
            if (isTrap(endR, endC)) return true // Any piece on a trap loses its rank power
            if (absAttacker == 1 && absDefender == 8) return true // Rat defeats Elephant
            if (absAttacker == 8 && absDefender == 1) return false // Elephant cannot capture Rat
            return absAttacker >= absDefender
        }

        return true
    }

    /**
     * Verifies that all intermediate squares between start and end are river tiles
     * and that no Rat (Rank 1) is currently in the water blocking the jump.
     */
    private fun checkRiverJumpPath(startR: Int, startC: Int, endR: Int, endC: Int): Boolean {
        if (startR == endR) {
            val minC = minOf(startC, endC)
            val maxC = maxOf(startC, endC)
            if (maxC - minC <= 1) return false
            for (c in (minC + 1) until maxC) {
                if (!isRiver(startR, c) || abs(boardState[startR][c]) == 1) return false
            }
            return true
        } else if (startC == endC) {
            val minR = minOf(startR, endR)
            val maxR = maxOf(startR, endR)
            if (maxR - minR <= 1) return false
            for (r in (minR + 1) until maxR) {
                if (!isRiver(r, startC) || abs(boardState[r][startC]) == 1) return false
            }
            return true
        }
        return false
    }

    /**
     * Evaluates and executes a legal move for the Blue AI Bot based on the selected difficulty level.
     */
    private fun makeBotMove() {
        val allMoves = mutableListOf<Triple<Int, Int, Pair<Int, Int>>>()

        // Gather all legal moves for Blue pieces (< 0), including river jumps
        for (r in 0..8) {
            for (c in 0..6) {
                if (boardState[r][c] < 0) {
                    for (tr in 0..8) {
                        for (tc in 0..6) {
                            if (isValidMove(r, c, tr, tc)) {
                                allMoves.add(Triple(r, c, Pair(tr, tc)))
                            }
                        }
                    }
                }
            }
        }

        if (allMoves.isNotEmpty()) {
            val chosenMove = when (difficultyIndex) {
                2 -> { // Hard: Prioritize capturing the Den, high-value captures, and advancing down the board
                    allMoves.maxByOrNull { move ->
                        val targetPiece = boardState[move.third.first][move.third.second]
                        val movingPiece = abs(boardState[move.first][move.second])
                        val isDenTarget = (move.third.first == 8 && move.third.second == 3)
                        when {
                            isDenTarget -> 200
                            movingPiece == 1 && targetPiece == 8 -> 150
                            targetPiece > 0 -> abs(targetPiece) * 10
                            else -> move.third.first
                        }
                    } ?: allMoves[Random.nextInt(allMoves.size)]
                }
                1 -> { // Medium: 70% chance to prefer capturing moves if available
                    val capturingMoves = allMoves.filter { boardState[it.third.first][it.third.second] > 0 }
                    if (capturingMoves.isNotEmpty() && Random.nextFloat() > 0.3f) {
                        capturingMoves[Random.nextInt(capturingMoves.size)]
                    } else {
                        allMoves[Random.nextInt(allMoves.size)]
                    }
                }
                else -> { // Easy: Random legal move
                    allMoves[Random.nextInt(allMoves.size)]
                }
            }

            executeMove(chosenMove.first, chosenMove.second, chosenMove.third.first, chosenMove.third.second)
        }
    }
}